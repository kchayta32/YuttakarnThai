using UnityEngine;
using UnityEngine.AI;

namespace RTS.Core
{
    [RequireComponent(typeof(NavMeshAgent))]
    public class UnitController : MonoBehaviour
    {
        [Header("Unit Stats")]
        public string UnitName;
        public float MaxHP = 100f;
        public float CurrentHP;
        public float AttackRange = 10f;
        public float AttackDamage = 10f;
        public float AttackRate = 1.5f;

        [Header("State")]
        public bool IsSelected = false;
        
        private NavMeshAgent agent;
        private Transform target;
        private float lastAttackTime;

        void Start()
        {
            agent = GetComponent<NavMeshAgent>();
            CurrentHP = MaxHP;
        }

        void Update()
        {
            if (target != null)
            {
                float distance = Vector3.Distance(transform.position, target.position);
                if (distance <= AttackRange)
                {
                    agent.isStopped = true;
                    // Combat Logic
                    if (Time.time > lastAttackTime + AttackRate)
                    {
                        Attack(target);
                        lastAttackTime = Time.time;
                    }
                }
                else
                {
                    agent.isStopped = false;
                    agent.SetDestination(target.position);
                }
            }
        }

        public void MoveTo(Vector3 position)
        {
            target = null; // Clear combat target
            agent.isStopped = false;
            agent.SetDestination(position);
        }

        public void SetTarget(Transform newTarget)
        {
            target = newTarget;
        }

        private void Attack(Transform t)
        {
            // Simple combat resolution call
            var enemy = t.GetComponent<UnitController>();
            if (enemy != null)
            {
                enemy.TakeDamage(AttackDamage);
            }
        }

        public void TakeDamage(float amount)
        {
            CurrentHP -= amount;
            if (CurrentHP <= 0)
            {
                Die();
            }
        }

        private void Die()
        {
            // Play animation, spawn particles
            Destroy(gameObject);
        }

        public void SetSelected(bool selected)
        {
            IsSelected = selected;
            // Toggle selection visual ring
            var ring = transform.Find("SelectionRing");
            if (ring) ring.gameObject.SetActive(selected);
        }
    }
}
